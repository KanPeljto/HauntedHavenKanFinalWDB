package com.example.hauntedhaven

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color

data class featuredListings(
    val title: String,
    val listingId: Int,
)
